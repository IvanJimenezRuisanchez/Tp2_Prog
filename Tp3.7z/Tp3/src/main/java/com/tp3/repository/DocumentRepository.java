package com.tp3.repository;

import com.tp3.model.Document;
import com.tp3.model.Livre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DocumentRepository extends JpaRepository<Document, Long> {
    @Query(value = "SELECT l from Livre l WHERE upper(l.titre) like :data")
    List<Livre> findByTitre(@Param("data") String data);

    @Query(value = "SELECT d from Document d WHERE upper(d.auteur) = :data")
    List<Livre> findByAuteur(@Param("data") String data);

    @Query(value = "SELECT d from Document d WHERE upper(d.categorie) = :data")
    List<Livre> findByCategorie(@Param("data") String data);

    @Query(value = "SELECT d from Document d WHERE d.anneePublication = :data")
    List<Livre> findByAndAnneePublication(@Param("data") String data);
}
