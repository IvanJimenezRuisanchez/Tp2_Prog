package com.tp3.service;

import com.tp3.dto.DocumentDto;
import com.tp3.model.*;
import com.tp3.repository.DocumentRepository;
import com.tp3.repository.EmpreuntRepository;
import com.tp3.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class ServiceClient{
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DocumentRepository documentRepository;
    @Autowired
    private EmpreuntRepository empreuntRepository;

    public Empreunt empreunter(long idUser, long idDocument) {
        Document document = documentRepository.findById(idDocument).get();
        String typeDocument = document.getClass().getName().toUpperCase();
        int nbrExemplaires = document.getNbrExemplaire();
        LocalDate dateFin = null;

        if(nbrExemplaires > 0) {
            switch (typeDocument) {
                case "LIVRE":
                    dateFin = LocalDate.now().plusWeeks(3);
                    break;
                case "CD":
                    dateFin = LocalDate.now().plusWeeks(2);
                    break;
                case "DVD":
                    dateFin = LocalDate.now().plusWeeks(1);
                    break;
            }
            Empreunt empreunt = new Empreunt((Client) userRepository.findById(idUser).get(), documentRepository.findById(idDocument).get(),
                    dateFin, "En cours");
            document.setNbrExemplaire(nbrExemplaires-1);
            documentRepository.save(document);
            return empreuntRepository.save(empreunt);
        }
        return null;
    }

    public List<DocumentDto> findLivre(String critereRecherche, String data) {
        List<Document> documents = null;
        switch (critereRecherche){
            case "TITRE":
                documents = documentRepository.findByTitre(data);
            case "AUTEUR":
                documents = documentRepository.findByAuteur(data);
            case "ANNEEPUBLICACION":
                documents = documentRepository.findByAndAnneePublication(data);
            case "CATEGORIE":
                documents = documentRepository.findByCategorie(data);
        }
        List<DocumentDto> documentsDto;
        for(Document document : documents){
            new DocumentDto(document.getTitre(),document.getAnneePublication(),document.getAuteur(),document.getNbrExemplaire(),document.get)
        }
        return
    }
}
